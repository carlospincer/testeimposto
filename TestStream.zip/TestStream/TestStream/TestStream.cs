﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CharStream;
using ProcessStream;

namespace TesteStreamForm
{
    public partial class TestStream : Form
    {
        public TestStream()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            var tstStr = new TstStream(txtInput.Text);
            var firstchar = new firstChar(tstStr);
            char? vogal = firstchar.GetfirstChar();

            txtOutput.Text = "";
            if (vogal != null)                
                txtOutput.Text = vogal.ToString();
            else
                MessageBox.Show("Não foi encontrada nenhuma vogal, conforme o requisito.");
                
        }


    }
}

﻿using ProcessStream;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharStream
{
    public class firstChar
    {
        private TstStream stream; 

        static char[] Vogais = { 'A', 'E', 'I', 'O', 'U' };

        public firstChar(TstStream stream)
        {
            this.stream = stream;
        }

        public char? GetfirstChar()
        {
            
            char? chrVogal = null;
            char? chrUltimo = null;
            List<char> vogaisEncontradas = new List<char>();

            while (stream.hasNext())
            {
                char chrAtual = stream.getNext();

                if (Char.IsLetter(chrAtual))
                {                  
  
                    if (chrUltimo != null) 
                    {
                        if (!isVogal(chrUltimo.Value) && isVogal(chrAtual))
                        {
                            chrVogal = chrAtual;
                            vogaisEncontradas.Add(char.ToUpper(chrVogal.Value));
                        }
                    }
                    chrUltimo = chrAtual;
                }
            }


            var lstVogais = vogaisEncontradas.GroupBy(g => g);

            var primeiraVogal = lstVogais.Where(x => x.Count() == 1).FirstOrDefault();

            if (primeiraVogal != null)
                return primeiraVogal.Key;
            else
                return null;
        }

        private static bool isVogal(char chr)
        {
            return Vogais.Contains(char.ToUpper(chr));
        }
    }
}

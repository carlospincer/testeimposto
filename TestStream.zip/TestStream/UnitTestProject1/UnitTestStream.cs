﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProcessStream;
using CharStream;
using System;

namespace UnitTestStream
{
    [TestClass]
    public class UnitTestStream
    {
        private string[] strValues = { "DSARSDISDTT", "RSRSDSDFSDFSDFG FDFGDFGDFGDFGDFGISDETT", "SDFSUFDUD" };

        [TestMethod]
        public void TestMethod1()
        {
            var tstStr = new TstStream(strValues[0].ToString());
            var firstchar = new firstChar(tstStr);
            char? vogal = firstchar.GetfirstChar();

            Assert.AreEqual("A", vogal.ToString(), "Não foi encontrada nenhuma vogal, conforme o requisito.");
        }

        [TestMethod]
        public void TestMethod2()
        {
            var tstStr = new TstStream(strValues[1].ToString());
            var firstchar = new firstChar(tstStr);
            char? vogal = firstchar.GetfirstChar();

            Assert.AreEqual("I", vogal.ToString(), "Não foi encontrada nenhuma vogal, conforme o requisito.");
        }

        [TestMethod]
        public void TestMethod3()
        {
            var tstStr = new TstStream(strValues[2].ToString());
            var firstchar = new firstChar(tstStr);
            char? vogal = firstchar.GetfirstChar();

            Assert.AreEqual("", vogal.ToString(), "Não foi encontrada nenhuma vogal, conforme o requisito.");

        }


    }
}
